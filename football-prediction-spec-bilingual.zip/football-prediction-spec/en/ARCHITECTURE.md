# Project Architecture

## 1. High-Level Diagram

```text
Free Football APIs
        |
        v
Data Collector
        |
        +--> Redis Cache
        |
        v
PostgreSQL + Prisma
        |
        +--> Feature Engine
        +--> Elo Engine
        +--> Poisson Engine
        +--> Odds Engine
        +--> Value Bet Engine
        +--> Backtest Engine
        |
        v
NestJS REST API
        |
        v
Next.js / React
```

## 2. Components

### apps/web
User interface:
- fixtures list;
- match page;
- predictions;
- value bets;
- model performance;
- backtesting.

### apps/api
Main backend:
- REST API;
- orchestration;
- future authentication;
- competition configuration;
- database access;
- background job scheduling.

### workers/data-sync
Background jobs:
- fixtures sync;
- results sync;
- standings sync;
- injuries sync;
- lineups sync;
- odds sync.

### packages/database
- Prisma schema;
- Prisma Client;
- migrations;
- seed.

### packages/domain
Shared domain types and enums.

### packages/football-data
Abstraction over external free football APIs.

Interface:
```ts
interface FootballDataProvider {
  getUpcomingFixtures(): Promise<FixtureDto[]>;
  getTeamRecentMatches(teamId: string): Promise<FixtureDto[]>;
  getStandings(leagueId: string): Promise<StandingDto[]>;
  getInjuries(fixtureId: string): Promise<InjuryDto[]>;
  getLineups(fixtureId: string): Promise<LineupDto[]>;
  getOdds(fixtureId: string): Promise<OddsDto[]>;
}
```

### packages/prediction
Contains:
- Elo;
- Poisson;
- feature builder;
- probability normalization;
- market calculations.

### packages/value-betting
Contains:
- implied probability;
- overround removal;
- edge;
- EV;
- value-bet filters.

### packages/backtesting
Contains:
- Brier Score;
- Log Loss;
- calibration;
- ROI/Yield;
- model comparison.

## 3. Data Flows

### Morning sync
1. Fetch fixtures for today and the next 48 hours.
2. Update completed fixtures.
3. Update standings.
4. Build features.
5. Create INITIAL snapshots.

### Before kickoff
1. Check injuries.
2. Check odds.
3. Recalculate PRE_MATCH snapshot.
4. Check lineups close to kickoff.
5. When official lineups exist, create LINEUP_CONFIRMED snapshot.

### After the match
1. Persist the result.
2. Update Elo.
3. Calculate backtest metrics.
4. Resolve BetCandidate result.

## 4. API Limit Protection

Introduce DailyApiBudget:
- provider;
- date;
- usedRequests;
- maxRequests;
- reservedCriticalRequests.

Priority levels:
- CRITICAL: fixtures/results;
- HIGH: lineups;
- MEDIUM: injuries/odds;
- LOW: secondary statistics.

## 5. Caching

Suggested Redis TTL:
- fixtures: 6 hours;
- standings: 12 hours;
- injuries: 3 hours;
- odds: 30–60 minutes;
- lineups: 10 minutes close to kickoff;
- historical results: persistent in PostgreSQL.

## 6. Reliability

- idempotent jobs;
- unique constraints on external IDs;
- retries with exponential backoff;
- provider error logging;
- circuit breaker for unstable APIs;
- immutable prediction snapshots.

## 7. Scaling

The MVP can run as one backend plus one worker.

Later it can be split into:
- ingestion service;
- prediction service;
- ML service;
- backtest service.
