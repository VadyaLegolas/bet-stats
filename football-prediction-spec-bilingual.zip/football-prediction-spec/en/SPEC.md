# Football Prediction & Value Betting Platform — Specification

## 1. Project Goal

Build a web application that automatically analyzes upcoming football matches from the top five European leagues and UEFA competitions, estimates event probabilities, and identifies potential value-bet opportunities.

The application must not claim that a bet will win. It must estimate probabilities and compare them with market odds.

## 2. Supported Competitions

- Premier League
- La Liga
- Serie A
- Bundesliga
- Ligue 1
- UEFA Champions League
- UEFA Europa League
- Optional: UEFA Conference League

The competition list must be configurable.

## 3. Data Source Constraint

The MVP must use only free tools and free data plans.

Primary source:
- API-Football Free

Fallback source:
- football-data.org Free

The MVP must not require:
- paid APIs;
- paid xG providers;
- paid odds providers;
- scraping that violates a source's Terms of Service.

## 4. Core Features

The system must:

1. discover upcoming fixtures;
2. persist fixtures in PostgreSQL;
3. collect recent team match history;
4. calculate 5-match and 10-match form;
5. analyze home and away form separately;
6. calculate Elo ratings;
7. use H2H with low predictive weight;
8. account for injuries, suspensions and unavailable players when free data exists;
9. use confirmed lineups when available;
10. calculate probabilities using Poisson + Elo + form;
11. support 1X2, Double Chance, Over/Under and BTTS;
12. ingest bookmaker odds when available for free;
13. calculate implied probability, edge and expected value;
14. persist immutable prediction snapshots;
15. perform backtesting after matches finish;
16. expose results through a React/Next.js interface.

## 5. Stack

### Frontend
- Next.js
- React
- TypeScript
- Tailwind CSS
- TanStack Query
- Recharts

### Backend
- Node.js
- TypeScript
- NestJS

### Data
- PostgreSQL
- Prisma
- Redis
- BullMQ

### Prediction V1
- TypeScript
- Poisson
- Elo

### Prediction V2+
- Python
- FastAPI
- pandas
- NumPy
- scikit-learn
- XGBoost or LightGBM

## 6. Data and Features

Use only fields that are actually available from free sources.

Candidate features:
- wins / draws / losses;
- goals for / against;
- goals per match;
- clean sheets;
- failed to score;
- shots;
- shots on target;
- possession;
- corners;
- yellow/red cards;
- league position;
- rest days;
- home/away form;
- Elo difference;
- H2H;
- missing-player impact;
- confirmed-lineup status.

## 7. Weighted Form

Recent games receive greater weight.

Example:
- match -1: 1.00
- match -2: 0.90
- match -3: 0.80
- match -4: 0.70
- match -5: 0.60

## 8. Prediction Engine V1

Base model:

Poisson + Elo + Recent Form + Home/Away Strength + H2H + Missing Players

Poisson calculates lambdaHome and lambdaAway, then builds a score probability matrix from at least 0:0 to 7:7.

Derived markets:
- Home / Draw / Away;
- 1X / X2 / 12;
- Over/Under 1.5;
- Over/Under 2.5;
- Over/Under 3.5;
- BTTS Yes/No;
- team totals.

## 9. Value Bet Engine

For decimal odds:

`impliedProbability = 1 / odds`

For multi-outcome markets normalize probabilities to remove bookmaker overround.

`edge = modelProbability - marketProbability`

`EV = modelProbability * odds - 1`

Recommended default filter:
- Edge >= 5%
- EV > 0

## 10. Confidence Score

Confidence is not the event probability.

Range: 0–100.

It should consider:
- historical sample size;
- data freshness;
- statistical coverage;
- injury information availability;
- confirmed lineup availability;
- model stability.

## 11. Prediction Snapshots

Predictions must never be changed retroactively.

Snapshot types:
- INITIAL
- PRE_MATCH
- LINEUP_CONFIRMED
- FINAL

Every snapshot must include capturedAt.

## 12. Backtesting

After matches finish calculate:
- Brier Score;
- Log Loss;
- Accuracy;
- Calibration;
- ROI;
- Yield;
- CLV when historical odds are available.

All backtests must prevent data leakage.

## 13. API Budget

Target: fewer than 100 external requests per day.

Update priority:
1. fixtures;
2. results;
3. lineups before kickoff;
4. injuries;
5. odds;
6. secondary statistics.

Historical data must be persisted and not downloaded repeatedly without need.

## 14. REST API

- GET /api/fixtures/upcoming
- GET /api/fixtures/:id
- GET /api/fixtures/:id/statistics
- GET /api/fixtures/:id/prediction
- GET /api/predictions/today
- GET /api/value-bets
- GET /api/teams/:id
- GET /api/teams/:id/form
- GET /api/models/performance
- GET /api/backtest

## 15. MVP Definition of Done

The MVP is complete when it can automatically:
1. fetch upcoming fixtures;
2. persist fixtures;
3. retrieve team history;
4. calculate form;
5. calculate Elo;
6. run Poisson;
7. generate 1X2 probabilities;
8. generate O/U 2.5 probabilities;
9. generate BTTS probabilities;
10. display predictions in the UI;
11. save a prediction snapshot;
12. retrieve the final result;
13. evaluate the quality of the previous prediction.
