# Архитектура проекта

## 1. Общая схема

```text
Free Football APIs
        |
        v
Data Collector
        |
        +--> Redis Cache
        |
        v
PostgreSQL + Prisma
        |
        +--> Feature Engine
        +--> Elo Engine
        +--> Poisson Engine
        +--> Odds Engine
        +--> Value Bet Engine
        +--> Backtest Engine
        |
        v
NestJS REST API
        |
        v
Next.js / React
```

## 2. Компоненты

### apps/web
Пользовательский интерфейс:
- список матчей;
- карточка матча;
- прогнозы;
- value bets;
- статистика моделей;
- backtesting.

### apps/api
Основной backend:
- REST API;
- orchestration;
- auth в будущем;
- конфигурация турниров;
- доступ к БД;
- постановка background jobs.

### workers/data-sync
Фоновые задачи:
- fixtures sync;
- results sync;
- standings sync;
- injuries sync;
- lineups sync;
- odds sync.

### packages/database
- Prisma schema;
- Prisma Client;
- migrations;
- seed.

### packages/domain
Общие доменные типы и enum.

### packages/football-data
Абстракция над внешними бесплатными API.

Интерфейс:
```ts
interface FootballDataProvider {
  getUpcomingFixtures(): Promise<FixtureDto[]>;
  getTeamRecentMatches(teamId: string): Promise<FixtureDto[]>;
  getStandings(leagueId: string): Promise<StandingDto[]>;
  getInjuries(fixtureId: string): Promise<InjuryDto[]>;
  getLineups(fixtureId: string): Promise<LineupDto[]>;
  getOdds(fixtureId: string): Promise<OddsDto[]>;
}
```

### packages/prediction
Содержит:
- Elo;
- Poisson;
- feature builder;
- probability normalization;
- market calculations.

### packages/value-betting
Содержит:
- implied probability;
- overround removal;
- edge;
- EV;
- value-bet filters.

### packages/backtesting
Содержит:
- Brier Score;
- Log Loss;
- calibration;
- ROI/Yield;
- model comparison.

## 3. Потоки данных

### Утренний sync
1. Получить fixtures на сегодня и ближайшие 48 часов.
2. Обновить завершённые матчи.
3. Обновить standings.
4. Вычислить признаки.
5. Создать INITIAL snapshot.

### Перед матчем
1. Проверить injuries.
2. Проверить odds.
3. Пересчитать PRE_MATCH snapshot.
4. Ближе к kickoff проверить lineups.
5. При наличии официального состава создать LINEUP_CONFIRMED snapshot.

### После матча
1. Сохранить результат.
2. Обновить Elo.
3. Рассчитать backtest metrics.
4. Зафиксировать результат BetCandidate.

## 4. Защита от превышения лимитов

Ввести DailyApiBudget:
- provider;
- date;
- usedRequests;
- maxRequests;
- reservedCriticalRequests.

Приоритет:
- CRITICAL: fixtures/results;
- HIGH: lineups;
- MEDIUM: injuries/odds;
- LOW: второстепенная статистика.

## 5. Кэширование

Redis TTL:
- fixtures: 6 часов;
- standings: 12 часов;
- injuries: 3 часа;
- odds: 30–60 минут;
- lineups: 10 минут перед матчем;
- исторические результаты: бессрочно в PostgreSQL.

## 6. Надёжность

- idempotent jobs;
- unique constraints на внешние IDs;
- retry с exponential backoff;
- логирование provider errors;
- circuit breaker для нестабильных API;
- snapshots не обновляются после создания.

## 7. Масштабирование

MVP может работать как один backend + один worker.

Позже можно разделить:
- ingestion service;
- prediction service;
- ML service;
- backtest service.
