# Структура monorepo

Рекомендуется pnpm workspaces + Turborepo.

```text
football-prediction/
├─ apps/
│  ├─ web/                       # Next.js frontend
│  │  ├─ app/
│  │  ├─ components/
│  │  ├─ features/
│  │  └─ lib/
│  └─ api/                       # NestJS backend
│     ├─ src/modules/fixtures/
│     ├─ src/modules/teams/
│     ├─ src/modules/predictions/
│     ├─ src/modules/value-bets/
│     ├─ src/modules/backtest/
│     └─ src/modules/providers/
│
├─ workers/
│  └─ data-sync/
│     ├─ src/jobs/fixtures.ts
│     ├─ src/jobs/results.ts
│     ├─ src/jobs/injuries.ts
│     ├─ src/jobs/lineups.ts
│     └─ src/jobs/odds.ts
│
├─ packages/
│  ├─ database/
│  │  ├─ prisma/schema.prisma
│  │  └─ src/client.ts
│  ├─ domain/
│  ├─ football-data/
│  │  ├─ src/providers/api-football/
│  │  ├─ src/providers/football-data-org/
│  │  └─ src/provider.interface.ts
│  ├─ prediction/
│  │  ├─ src/elo/
│  │  ├─ src/poisson/
│  │  ├─ src/features/
│  │  └─ src/markets/
│  ├─ value-betting/
│  ├─ backtesting/
│  ├─ config/
│  └─ ui/
│
├─ infra/
│  ├─ docker-compose.yml
│  └─ postgres/
│
├─ docs/
│  ├─ SPEC.md
│  └─ ARCHITECTURE.md
│
├─ .env.example
├─ package.json
├─ pnpm-workspace.yaml
└─ turbo.json
```

## Основные env-переменные

```env
DATABASE_URL=
REDIS_URL=
API_FOOTBALL_KEY=
FOOTBALL_DATA_ORG_KEY=
API_FOOTBALL_DAILY_LIMIT=100
```

## Рекомендуемые npm scripts

```json
{
  "scripts": {
    "dev": "turbo dev",
    "build": "turbo build",
    "lint": "turbo lint",
    "test": "turbo test",
    "db:generate": "pnpm --filter database prisma generate",
    "db:migrate": "pnpm --filter database prisma migrate dev"
  }
}
```
