# Football Prediction & Value Betting Platform — Спецификация

## 1. Цель проекта

Создать веб-приложение для автоматического анализа ближайших футбольных матчей топ-5 европейских лиг и еврокубков, расчёта вероятностей футбольных событий и поиска потенциальных value-bet возможностей.

Приложение не должно обещать выигрыш. Оно должно оценивать вероятности и сравнивать их с рыночными коэффициентами.

## 2. Поддерживаемые турниры

- Premier League
- La Liga
- Serie A
- Bundesliga
- Ligue 1
- UEFA Champions League
- UEFA Europa League
- Опционально: UEFA Conference League

Список турниров должен задаваться через конфигурацию.

## 3. Ограничение по источникам данных

Для MVP используются только бесплатные инструменты и бесплатные тарифы.

Основной источник:
- API-Football Free

Резервный источник:
- football-data.org Free

Запрещено делать обязательной частью MVP:
- платные API;
- платные xG-провайдеры;
- платные odds-провайдеры;
- scraping, нарушающий Terms of Service источника.

## 4. Основные функции

Система должна:

1. находить ближайшие матчи;
2. сохранять матчи в PostgreSQL;
3. собирать историю последних матчей команд;
4. рассчитывать форму за 5 и 10 матчей;
5. отдельно учитывать домашнюю и выездную форму;
6. рассчитывать Elo-рейтинг;
7. учитывать H2H с небольшим весом;
8. учитывать травмы, дисквалификации и отсутствующих игроков, если данные доступны бесплатно;
9. использовать официальные составы, когда они доступны;
10. рассчитывать вероятности через Poisson + Elo + форму;
11. поддерживать рынки 1X2, Double Chance, Over/Under и BTTS;
12. получать коэффициенты, если они доступны бесплатно;
13. рассчитывать implied probability, edge и expected value;
14. сохранять immutable prediction snapshots;
15. выполнять backtesting после завершения матчей;
16. показывать результаты в React/Next.js интерфейсе.

## 5. Стек

### Frontend
- Next.js
- React
- TypeScript
- Tailwind CSS
- TanStack Query
- Recharts

### Backend
- Node.js
- TypeScript
- NestJS

### Data
- PostgreSQL
- Prisma
- Redis
- BullMQ

### Prediction V1
- TypeScript
- Poisson
- Elo

### Prediction V2+
- Python
- FastAPI
- pandas
- NumPy
- scikit-learn
- XGBoost или LightGBM

## 6. Данные и признаки

Использовать только реально доступные поля.

Кандидатные признаки:
- wins / draws / losses;
- goals for / against;
- goals per match;
- clean sheets;
- failed to score;
- shots;
- shots on target;
- possession;
- corners;
- yellow/red cards;
- league position;
- rest days;
- home/away form;
- Elo difference;
- H2H;
- missing players impact;
- confirmed lineup status.

## 7. Weighted Form

Последние матчи получают больший вес.

Пример:
- матч -1: 1.00
- матч -2: 0.90
- матч -3: 0.80
- матч -4: 0.70
- матч -5: 0.60

## 8. Prediction Engine V1

Базовая модель:

Poisson + Elo + Recent Form + Home/Away Strength + H2H + Missing Players

Poisson рассчитывает lambdaHome и lambdaAway, затем строит матрицу вероятностей счёта минимум от 0:0 до 7:7.

Из неё выводятся:
- Home / Draw / Away;
- 1X / X2 / 12;
- Over/Under 1.5;
- Over/Under 2.5;
- Over/Under 3.5;
- BTTS Yes/No;
- team totals.

## 9. Value Bet Engine

Для decimal odds:

`impliedProbability = 1 / odds`

Для многовариантных рынков необходимо нормализовать вероятности, чтобы убрать bookmaker overround.

`edge = modelProbability - marketProbability`

`EV = modelProbability * odds - 1`

Рекомендуемый фильтр по умолчанию:
- Edge >= 5%
- EV > 0

## 10. Confidence Score

Confidence не равен вероятности события.

Диапазон: 0–100.

Он должен учитывать:
- объём исторических данных;
- свежесть данных;
- полноту статистики;
- наличие информации о травмах;
- наличие подтверждённых составов;
- стабильность модели.

## 11. Prediction Snapshots

Прогнозы нельзя изменять задним числом.

Типы snapshot:
- INITIAL
- PRE_MATCH
- LINEUP_CONFIRMED
- FINAL

Каждый snapshot содержит capturedAt.

## 12. Backtesting

После завершения матчей рассчитывать:
- Brier Score;
- Log Loss;
- Accuracy;
- Calibration;
- ROI;
- Yield;
- CLV, если доступна история коэффициентов.

Все тесты должны предотвращать data leakage.

## 13. API Budget

Цель: меньше 100 внешних запросов в день.

Приоритет обновлений:
1. fixtures;
2. результаты;
3. составы перед матчем;
4. травмы;
5. odds;
6. второстепенная статистика.

Исторические данные кэшируются в БД и повторно не загружаются без необходимости.

## 14. REST API

- GET /api/fixtures/upcoming
- GET /api/fixtures/:id
- GET /api/fixtures/:id/statistics
- GET /api/fixtures/:id/prediction
- GET /api/predictions/today
- GET /api/value-bets
- GET /api/teams/:id
- GET /api/teams/:id/form
- GET /api/models/performance
- GET /api/backtest

## 15. MVP Definition of Done

MVP готов, когда он автоматически:
1. получает ближайшие матчи;
2. сохраняет их;
3. загружает историю команд;
4. рассчитывает форму;
5. рассчитывает Elo;
6. запускает Poisson;
7. строит вероятности 1X2;
8. строит O/U 2.5;
9. строит BTTS;
10. отображает прогноз в интерфейсе;
11. сохраняет snapshot;
12. получает финальный результат;
13. оценивает качество прошлого прогноза.
